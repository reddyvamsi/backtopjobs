import {combineReducers} from 'redux';
import JobReducer from './Job-reducer';
const rootReducer = combineReducers(
    {
    users:JobReducer,
});




export default rootReducer;