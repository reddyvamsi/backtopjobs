const  intialstate={
    jobs:[],
}

const JobReducer=(state=intialstate, action)=>{
    console.log(action.type);
    switch(action.type){
        case "job/getById":
            console.log(action.data)
            return {
                ...state, jobs: action.data,
                }
            default:
                console.log(state.jobs)
                return state;
    }

}
export default JobReducer