import axios from 'axios'; 
// export const getjobs=(jobs)=>{
//   console.log('get all', jobs)
//   return {
//       type:'job',
//       data:jobs
//   }
// }

export const  getj=(id)=>{
 return async function(dispatch, getstate){
     await axios.get('http://localhost:1111/jobs')
     .then(data=>{
         console.log("vamsi",data);
         return dispatch({
             type:"job/getById",
             data:data.data
         })
     })

 }
}
