import { applyMiddleware, createStore } from "redux";
import thunk from "redux-thunk";
//import {createStore} from "redux";
import JobReducer from "./redux/reducer/Job-reducer";
//import { composeWithDevTools } from "redux-devtools-extension";

const Store = createStore(JobReducer,applyMiddleware(thunk));
//const store = createStore(employeeReducer);
export default Store;