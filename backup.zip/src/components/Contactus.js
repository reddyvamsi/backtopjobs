import React from "react";
import  "./Contactus.css"
import conUS from '../images/conUS.jpg';

const Contactus=()=>{
    return(
        <>
        <div class="container">
            <div class="row" style={{position:"relative",top: "3rem"}}>
                <div class="col-6">
              <p className="titlestyle">Get In Touch</p>
              <form>
    <div class="form-group">
    <input type="email"  class="form-control inputsapce" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name"></input>
  </div>
  <div class="form-group">
    <input type="email" class="form-control inputsapce" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"></input>
  </div>
  <div class="form-group">
    <input type="password" class="form-control inputsapce" id="exampleInputPassword1" placeholder="Password"></input>
  </div>
  <div class="form-group">
    <textarea class="form-control inputsapce" id="exampleFormControlTextarea1" placeholder="Message" rows="3"></textarea>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
                </div>
                <div class="col-6">
                <img style={{height:"400px"}}
                        className="d-block w-100"
                        src={conUS}
                        alt="First slide"
                    />

                </div>
            </div>
        </div>
        </>
    ) 
   
}
export default Contactus