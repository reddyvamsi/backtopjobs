import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {getj} from '../redux/actions/JobActions'

const Jobs=(props)=>{
    // let dispatch = useDispatch();
    // const {users} =useSelector(state => state.users);
    // console.log(users);
    // useEffect(() => {
    //     dispatch(getj());
    //     },[dispatch])
    return (
        <>
      <h1>jobs</h1>
        {/* <Cards 
       /> */}
     
        {/* <h1>{props.id}</h1>
        <h1>{props.company}</h1>
        <h1>{props.location}</h1> */}
        </>
    ) 
   
}
export default Jobs